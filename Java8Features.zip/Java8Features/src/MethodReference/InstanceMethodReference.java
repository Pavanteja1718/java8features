package MethodReference;

//method reference is used to refer the method of functional interface

interface SaySomething{
    public void say();
}

public class InstanceMethodReference {

    public void say(){
        System.out.println("hi from non-static method...!");
    }

    public static void main(String[] args) {
        InstanceMethodReference reference = new InstanceMethodReference();

        SaySomething saySomething = reference::say; //()-> reference.say();

        saySomething.say();
    }
}
