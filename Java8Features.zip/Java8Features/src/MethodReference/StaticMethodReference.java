package MethodReference;

interface Demo{
    public void say();
}

public class StaticMethodReference {

    public static void say(){
        System.out.println("hi from Static method...!");
    }

    public static void main(String[] args) {

        Demo demo = StaticMethodReference::say; //()-> StaticMethodReference.say();

        demo.say();
    }
}
