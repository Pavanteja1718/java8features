package practise;

interface Shape {
    public void area(int length); //shows only essential code and hides impl details
}

class  Square implements Shape{

    @Override
    public void area(int side) {
        System.out.println(side * side);
    }
}

class Circle implements  Shape{

    @Override
    public void area(int radius) {
        System.out.println(3.14 * radius * radius);
    }
}

public class DataAbstraction {
    public static void main(String[] args) {
        Shape square = new Square();

        Shape circle = new Circle();

        square.area(5);

        circle.area(10);
    }
}
