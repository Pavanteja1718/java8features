package practise;


class Phone {
    public String brand;
    public double price;
    public static String type ;    //static variable

    public void show() {
        System.out.println(brand + " : " + price + " : " + type);
    }

    //static method with static variable and non-static variables
    public  static  void display(Phone phone){
        System.out.println("static method is called...!");
        System.out.println(phone.brand + " : " + phone.price + " : " + type);
    }

    //static block called only once.
    static {
        System.out.println("hey i am static block...!");
        type = "smart phone";

    }
}

public class StaticExample {

    public static void main(String[] args) {
        Phone phone1 = new Phone();

        phone1.brand = "Apple";
        phone1.price = 25000.00;

        Phone phone2 = new Phone();

        phone2.brand = "MI";
        phone2.price = 15000.00;

        phone1.show();
        phone2.show();

        Phone.display(phone1);
        Phone.display(phone2);
    }

}
