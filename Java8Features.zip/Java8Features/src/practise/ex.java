package practise;

class Demo1 {

    public static void display(){
        System.out.println("i am static block in parent");
    }
}
public class ex extends Demo1{

    public static void display(){
        System.out.println("i am static block in child");
    }

    public static void main(String[] args) {
        Demo1 demo1 = new ex();

        ex.display();
    }

}

