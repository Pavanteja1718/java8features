package practise;

public class ExceptionExample {

    public static void main(String[] args) {

        try{
            int  y = 10/0;

        }
        catch (Exception e){
            System.out.println("exeception...!" + e);
        }

    }
}
