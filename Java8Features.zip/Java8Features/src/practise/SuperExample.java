package practise;

class Person {

    public String name;
    public int age;

    public Person() {
    }

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

class Student extends Person {

    public String schoolName;

    public Student(String name, int age, String schoolName) {
        super(name, age);
        this.schoolName = schoolName;
    }

    public void display() {
        System.out.println(name + " : " + age + " : " + schoolName);
    }

}

public class SuperExample {

    public static void main(String[] args) {
        Student student = new Student("abhi", 13, "govt high school");

        student.display();
    }
}
