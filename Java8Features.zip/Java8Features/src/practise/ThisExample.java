package practise;

class Employee {
    private String name;
    private String department;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void display() {
        System.out.println(name + " : " + department);
    }
}

public class ThisExample {

    public static void main(String[] args) {
        Employee emp1 = new Employee();

        emp1.setName("john");
        emp1.setDepartment("developer");

        emp1.display();
    }
}
