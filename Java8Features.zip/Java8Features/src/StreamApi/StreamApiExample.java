package StreamApi;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class StreamApiExample {

    public static void main(String[] args) {

        List<Employee> employeeList = new ArrayList<>();

        employeeList.add(new Employee(1,"ramesh",24000.00));
        employeeList.add(new Employee(2,"john",37000.00));
        employeeList.add(new Employee(3,"vivek",18000.00));
        employeeList.add(new Employee(4,"yash",41000.00));

        List<String> employeeNames = employeeList.stream()
                .filter(employee -> employee.getSalary() >= 30000.00)
                .map(employee -> employee.getName())
                .collect(Collectors.toList());

        double totalSalary = employeeList.stream()
                        .collect(Collectors.summingDouble(emp -> emp.getSalary()));

        System.out.println(employeeNames);

        System.out.println(totalSalary);
    }
}
