package ForEach;

//forEach() provides to iterate the elements

import java.util.*;

public class ForEachExample {

    public static void main(String[] args) {

        List<String> students = new ArrayList<>();

        students.add("ramesh");
        students.add("john");
        students.add("vivek");
        students.add("bhanu");

        students.forEach(student -> System.out.println(student));
    }
}
