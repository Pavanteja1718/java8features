package StringJoiner;

import java.util.StringJoiner;

//It is used to construct a sequence of characters separated by a delimiter.

public class StringJoinerExample {

    public static void main(String[] args) {

        StringJoiner joiner = new StringJoiner(",","[","]");

        joiner.add("ramesh");
        joiner.add("vivek");

        StringJoiner joiner1 = new StringJoiner(":","[","]");

        joiner1.add("abhi");
        joiner1.add("yash");

        StringJoiner merge = joiner.merge(joiner1);



        System.out.println(merge);

    }
}
