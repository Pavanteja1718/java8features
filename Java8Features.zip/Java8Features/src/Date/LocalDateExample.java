package Date;

import java.time.LocalDate;

public class LocalDateExample {

    public static void main(String[] args) {

        LocalDate date = LocalDate.now();

        System.out.println("yesterday date : " + date.minusDays(1));

        System.out.println("today date : " + date);

        System.out.println("tomorrow date : " + date.plusDays(1));

        System.out.println(date.isLeapYear());


        LocalDate date1 = LocalDate.of(2000, 01, 20);

        System.out.println(date1.isLeapYear());
    }
}
