package Date;

import java.time.LocalTime;

public class LocalTimeExample {

    public static void main(String[] args) {

        LocalTime time = LocalTime.now();

        System.out.println("current time is : " + time);
    }
}
