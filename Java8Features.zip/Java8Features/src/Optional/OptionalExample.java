package Optional;

import java.util.*;

//Optional is used to handle the nullpointer exception and
// checks the value present in the specific variable

public class OptionalExample {

    public static void main(String[] args) {

        String str[] = new String[10];

//        str[5] = "HELLO";

        Optional<String> checkNull = Optional.ofNullable(str[5]);

        if(checkNull.isPresent()){
            String lowerString = str[5].toLowerCase();
            System.out.println(lowerString);
        }
        else{
            System.out.println("no value is present in array...!");
        }
    }

}
