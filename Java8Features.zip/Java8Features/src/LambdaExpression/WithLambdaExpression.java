package LambdaExpression;

//lambda expression is used to implement the functional interface method in a simple concise and clear way.

interface Shape {
    public int square(int side);
}

public class WithLambdaExpression {

    public static void main(String[] args) {

        Shape shape = (side) -> side * side;

        System.out.println(shape.square(4));
    }
}
