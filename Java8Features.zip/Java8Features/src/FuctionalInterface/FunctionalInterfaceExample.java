package FuctionalInterface;

// functional interface has only one abstract method

interface Vehicle{
    public void drive();
}
public class FunctionalInterfaceExample  implements  Vehicle{

    public void drive() {
        System.out.println("I am driving vehicle");
    }

    public static void main(String[] args) {

        FunctionalInterfaceExample instance = new FunctionalInterfaceExample();

        instance.drive();
    }
}


